--
-- PostgreSQL database dump
--

-- Dumped from database version 13.7
-- Dumped by pg_dump version 13.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name character varying,
    screen_name character varying,
    is_closed integer,
    type character varying,
    query_id integer,
    user_id integer
);


ALTER TABLE public.groups OWNER TO db_user;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_id_seq OWNER TO db_user;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: queries; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.queries (
    id integer NOT NULL,
    query_date_time timestamp without time zone,
    query character varying
);


ALTER TABLE public.queries OWNER TO db_user;

--
-- Name: queries_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.queries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.queries_id_seq OWNER TO db_user;

--
-- Name: queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.queries_id_seq OWNED BY public.queries.id;


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: queries id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.queries ALTER COLUMN id SET DEFAULT nextval('public.queries_id_seq'::regclass);


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.groups (id, name, screen_name, is_closed, type, query_id, user_id) FROM stdin;
\.


--
-- Data for Name: queries; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.queries (id, query_date_time, query) FROM stdin;
\.


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, false);


--
-- Name: queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.queries_id_seq', 1, false);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: queries queries_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_pkey PRIMARY KEY (id);


--
-- Name: ix_groups_id; Type: INDEX; Schema: public; Owner: db_user
--

CREATE INDEX ix_groups_id ON public.groups USING btree (id);


--
-- Name: ix_groups_user_id; Type: INDEX; Schema: public; Owner: db_user
--

CREATE INDEX ix_groups_user_id ON public.groups USING btree (user_id);


--
-- Name: ix_queries_id; Type: INDEX; Schema: public; Owner: db_user
--

CREATE INDEX ix_queries_id ON public.queries USING btree (id);


--
-- Name: groups groups_query_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_query_id_fkey FOREIGN KEY (query_id) REFERENCES public.queries(id);


--
-- PostgreSQL database dump complete
--

